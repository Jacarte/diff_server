from django.apps import AppConfig


class DiffConfig(AppConfig):
    name = 'diff'
